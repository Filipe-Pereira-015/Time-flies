/*Banco de dados do Vinculado ao Sistema TIME FLIES*/

/*Exclusão do Banco*/
DROP DATABASE IF EXISTS time_fliesgerenciador;

/*Criação e Inicialização*/
CREATE DATABASE IF NOT EXISTS time_fliesgerenciador;
USE time_fliesgerenciador;

-- Tabela de Usuários
/*Tabela vinculada a página de Cadastro*/
CREATE TABLE IF NOT EXISTS Usuarios (
    usuario_id INT PRIMARY KEY AUTO_INCREMENT,
    nome_completo VARCHAR(80) NOT NULL,
    email VARCHAR(80) NOT NULL,
    cpf VARCHAR(11) NOT NULL,
    senha VARCHAR(255) NOT NULL
);

-- Tabela de Questões
/*Tabela vinculada a página pagExerc.php*/
CREATE TABLE questoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data DATE NOT NULL,
    total_questoes INT NOT NULL,
    acertos INT NOT NULL,
    erradas INT NOT NULL,
    tipo_estudo ENUM('ensino_regular', 'concurso_publico') NOT NULL,
    materia VARCHAR(100) NOT NULL
);

-- Tabela de plano_estudo
/*Tabela vinculada a página Plano de Estudos*/
CREATE TABLE plano_estudo (
    id INT(11) PRIMARY KEY,
    data DATE,
    conteudo TEXT,
    status VARCHAR(20),
    materia VARCHAR(100) DEFAULT NULL
);

-- Tabela de agendamento
-- Tabela vinculada a página AgendaRevisao.php
CREATE TABLE agendamento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    data DATE NOT NULL,
    conteudo VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    materia VARCHAR(100) NOT NULL,
    numero_agendamento VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE anexos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_arquivo VARCHAR(255) NOT NULL,
    caminho_arquivo VARCHAR(255) NOT NULL,
    tamanho INT NOT NULL,
    tipo_mime VARCHAR(255) NOT NULL,
    observacao TEXT,
    materia VARCHAR(100), -- Adicionando a coluna para a matéria
    data_upload TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Inserir usuários de exemplo
INSERT INTO Usuarios (nome_completo, email, cpf, senha ) VALUES
('Filipe Pereira', 'filipemarreira5@gmail.com', '08510756146', '123456789');

SELECT * FROM plano_estudo;
SELECT * FROM agendamento;
SELECT * FROM Usuarios;
SELECT * FROM anexos;
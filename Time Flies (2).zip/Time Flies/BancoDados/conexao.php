<?php
// Conexão com o Banco de Dados Time_fliesgerenciador
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

// Estabelece a conexão
$conexao = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}
?>
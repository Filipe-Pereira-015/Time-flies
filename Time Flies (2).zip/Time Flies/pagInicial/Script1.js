// Array de objetos representando as matérias
var subjects = [
    { id: "portugues", title: "Língua Portuguesa", type: "concurso", image: "../img/branco.jpg", url: "../pagMaterias/portugues.php" },
    { id: "matematica", title: "Mat. Básica", type: "concurso", image: "../img/azul.jpg", url: "../pagMaterias/matematica.php" },
    { id: "informatica", title: "Informática", type: "concurso", image: "../img/verde.avif", url: "../pagMaterias/informatica.php" },
    { id: "direito-constitucional", title: "Direito Const.", type: "concurso", image: "../img/amarelo.avif", url: "../pagMaterias/direito-constitucional.php" },
    { id: "direito-administrativo", title: "Direito Adm.", type: "concurso", image: "../img/laranja.avif", url: "../pagMaterias/direito-administrativo.php" },
    { id: "legislacao", title: "Legislação", type: "concurso", image: "../img/roxo.avif", url: "../pagMaterias/legislacao.php" },
    { id: "raciocinio-logico", title: "Raciocínio Lógico", type: "concurso", image: "../img/vermelho.webp", url: "../pagMaterias/raciocinio-logico.php" },
    { id: "direito-penal", title: "Direito Penal", type: "concurso", image: "../img/azul-escuro.webp", url: "../pagMaterias/direito-penal.php" },
    { id: "direito-civil", title: "Direito Civil", type: "concurso", image: "../img/degrade-color.webp", url: "../pagMaterias/direito-civil.php" },
    { id: "conhecimentos-gerais", title: "Conhec. Gerais", type: "concurso", image: "../img/azul-claro.webp", url: "../pagMaterias/conhecimentos-gerais.php" },
    { id: "matematica_regular", title: "Mat. Básica", type: "regular", image: "../img/gradiente-regular.jpg", url: "../pagMaterias/matematica_regular.php" },
    { id: "historia_regular", title: "História", type: "regular", image: "../img/reg-02.avif", url: "../pagMaterias/historia_regular.php" },
    { id: "geografia_regular", title: "Geografia", type: "regular", image: "../img/reg-3.jpg", url: "../pagMaterias/geografia_regular.php" },
    { id: "fisica_regular", title: "Física", type: "regular", image: "../img/reg-4.jpg", url: "../pagMaterias/fisica_regular.php" },
    { id: "quimica_regular", title: "Química", type: "regular", image: "../img/reg-5.jpg", url: "../pagMaterias/quimica_regular.php" },
    { id: "biologia_regular", title: "Biologia", type: "regular", image: "../img/reg-6.avif", url: "../pagMaterias/biologia_regular.php" }
];

// Função para criar os cards das matérias
function createSubjectCards() {
    var container = document.getElementById("subjects-container");
    container.innerHTML = "";

    subjects.forEach(function (subject) {
        var card = document.createElement("div");
        card.id = subject.id;
        card.className = "card subject-content " + subject.type + " card-image";
        card.style.backgroundImage = "url('" + subject.image + "')";
        card.innerHTML = `
            <a href="${subject.url}" style="text-decoration: none;">
                <div class="card-content">
                    <h2>${subject.title}<br><br>${subject.type == 'concurso' ? 'Concurso' : 'Regular'}</h2>
                    <p>Acesse a Matéria</p>
                </div>
            </a>
        `;
        container.appendChild(card);
    });
}

// Chama a função para criar os cards das matérias ao carregar a página
window.onload = createSubjectCards;

// Função para pesquisar matérias
function searchSubjects() {
    var input, filter, cards, cardContainer, title, i;
    input = document.getElementById("search-input");
    filter = input.value.toUpperCase();
    cardContainer = document.getElementById("subjects-container");
    cards = cardContainer.getElementsByClassName("card");

    for (i = 0; i < cards.length; i++) {
        title = cards[i].querySelector(".card-content h2");
        if (title.innerText.toUpperCase().indexOf(filter) > -1) {
            cards[i].style.display = "";
        } else {
            cards[i].style.display = "none";
        }
    }
}

// Função para limpar a pesquisa
function clearSearch() {
    document.getElementById("search-input").value = "";
    searchSubjects();
}

// Função para filtrar matérias por tipo (concurso/regular)
function filterSubjects(type) {
    var cards, cardContainer, i;
    cardContainer = document.getElementById("subjects-container");
    cards = cardContainer.getElementsByClassName("card");

    if (type == "all") {
        for (i = 0; i < cards.length; i++) {
            cards[i].style.display = "";
        }
    } else {
        for (i = 0; i < cards.length; i++) {
            if (cards[i].classList.contains(type)) {
                cards[i].style.display = "";
            } else {
                cards[i].style.display = "none";
            }
        }
    }
}
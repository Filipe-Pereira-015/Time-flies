// Define o tempo limite de inatividade em milissegundos (5 minutos)
const inactivityTimeout = 5 * 60 * 1000; // 5 minutos em milissegundos

// Define a função para redirecionar para a página de login
function redirectToLogin() {
    window.location.href = "login.php";
}

// Define a função para verificar a inatividade do usuário
function checkUserActivity() {
    let lastActivityTime = new Date().getTime();

    function checkInactivity() {
        let currentTime = new Date().getTime();
        if (currentTime - lastActivityTime >= inactivityTimeout) {
            redirectToLogin(); // Redireciona para a página de login se estiver inativo por mais de 5 minutos
        } else {
            // Atualiza o tempo da última atividade
            lastActivityTime = currentTime;
        }
    }

    // Verifica a inatividade do usuário a cada minuto
    setInterval(checkInactivity, 60 * 1000); // Verifica a cada minuto (60 segundos * 1000 milissegundos)
}

// Chama a função para verificar a inatividade do usuário quando a página é carregada
checkUserActivity();
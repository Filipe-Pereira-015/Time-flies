<?php
require_once "../login/verificarLogin.php";
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Time Flies - Materias</title>
    <link rel="stylesheet" href="stylePagInicial.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
</head>
<body>
    <div class="container mt-4">
    <div class="card-container">
    <h1>Temporizador de Sessão</h1>
    <p>O tempo de sessão atual é: <span id="tempo-sessao">00:00:00</span></p>
    <button class="btn btn-primary" onclick="location.reload()">Atualizar</button>
    <a href="../index.html" class="btn btn-primary">Página Inicial</a>
    <a href="../login/login.php" class="btn btn-danger mr-2">Encerrar Sessão</a>
</div>
<div class="card-container">
<p><strong>ACOMPANHAMENTO</strong></p> 
    <a href="../pagExerc/gerar_relatorio.php" class="btn btn-primary">Visão Geral</a>
    <a href="../pagExerc/pagExerc.php" class="btn btn-primary">Exercícios</a>
    <a href="../pagProgramacao/programacao.php" class="btn btn-primary">Programação</a>
    <a href="../pagRevisao/AgendaRevisao.php" class="btn btn-primary">Agendar</a>
    <a href="../paganexos/anexos.php" class="btn btn-primary">Anexar/Baixar</a>
</div>
    <div class="card-container">
    <p><strong>MINHAS MATÉRIAS</strong></p>
            <div class="search-container" id="search-container">
                <input type="text" id="search-input" class="form-control" placeholder="Pesquisar matérias...">
                <div class="input-group-append">
                    <button class="btn btn-primary" onclick="searchSubjects()">Buscar</button>
                    <button class="btn btn-outline-secondary" onclick="clearSearch()">Limpar</button>
                </div>               
            </div>

            <div class="button-group mt-3">

                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-primary" onclick="filterSubjects('all')">Todas</button>
                    <button type="button" class="btn btn-outline-primary" onclick="filterSubjects('concurso')">Concurso</button>
                    <button type="button" class="btn btn-outline-primary" onclick="filterSubjects('regular')">Ensino Regular</button>
                </div>
            </div>

            <div class="grid mt-4" id="subjects-container"> 

<!-- MATERIAS RELACIONADAS A CONCURSO PÚBLICO-->

<!-- Português -->
<div id="portugues" class="card subject-content concurso card-image" style="background-image: url('../img/branco.jpg');">
    <a href="../pagMaterias/portugues.php?cpf=<?php echo $cpfUsuario; ?>" style="text-decoration: none;">
        <div class="card-content">
            <h2>Lingua Portuguesa <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Matemática -->
<div id="matematica" class="card subject-content concurso card-image" style="background-image: url('../img/azul.jpg');">
    <a href="../pagMaterias/matematica.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Mat. Basica<br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Informática -->
<div id="informatica" class="card subject-content concurso card-image" style="background-image: url('../img/verde.avif');">
    <a href="../pagMaterias/informatica.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Informática <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Direito Constitucional -->
<div id="direito-constitucional" class="card subject-content concurso card-image" style="background-image: url('../img/amarelo.avif');">
    <a href="../pagMaterias/direito-constitucional.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Direito Const. <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Direito Administrativo -->
<div id="direito-administrativo" class="card subject-content concurso card-image" style="background-image: url('../img/laranja.avif');">
    <a href="../pagMaterias/direito-administrativo.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Direito Adm. <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Legislação -->
<div id="legislacao" class="card subject-content concurso card-image" style="background-image: url('../img/roxo.avif');">
    <a href="../pagMaterias/legislacao.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Legislação <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Raciocínio Lógico -->
<div id="raciocinio-logico" class="card subject-content concurso card-image" style="background-image: url('../img/vermelho.webp');">
    <a href="../pagMaterias/raciocinio-logico.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Raciocínio Lógico <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Direito Penal -->
<div id="direito-penal" class="card subject-content concurso card-image" style="background-image: url('../img/azul-escuro.webp');">
    <a href="../pagMaterias/direito-penal.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Direito Penal <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Direito Civil -->
<div id="direito-civil" class="card subject-content concurso card-image" style="background-image: url('../img/degrade-color.webp');">
    <a href="../pagMaterias/direito-civil.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Direito Civil <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Conhecimentos Gerais -->
<div id="conhecimentos-gerais" class="card subject-content concurso card-image" style="background-image: url('../img/azul-claro.webp');">
    <a href="../pagMaterias/conhecimentos-gerais.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Conhec. Gerais <br><br>Concurso</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- MATERIAS RELACIONADA AO ENSINO REGULAR-->

<!-- Matemática -->
<div id="matematica" class="card subject-content regular card-image" style="background-image: url('../img/gradiente-regular.jpg');">
    <a href="../pagMaterias/matematica_regular.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Mat. Básica<br><br>Regular</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- História -->
<div id="historia" class="card subject-content regular card-image" style="background-image: url('../img/reg-02.avif');">
    <a href="../pagMaterias/historia_regular.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>História<br><br>Regular</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Geografia -->
<div id="geografia" class="card subject-content regular card-image" style="background-image: url('../img/reg-3.jpg');">
    <a href="../pagMaterias/geografia_regular.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Geografia<br><br>Regular</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Física -->
<div id="fisica" class="card subject-content regular card-image" style="background-image: url('../img/reg-4.jpg');">
    <a href="../pagMaterias/fisica_regular.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Física<br><br>Regular</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Química -->
<div id="quimica" class="card subject-content regular card-image" style="background-image: url('../img/reg-5.jpg');">
    <a href="../pagMaterias/quimica_regular.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Química<br><br>Regular</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>

<!-- Biologia -->
<div id="biologia" class="card subject-content regular card-image" style="background-image: url('../img/reg-6.avif');">
    <a href="../pagMaterias/biologia_regular.php" style="text-decoration: none;">
        <div class="card-content">
            <h2>Biologia<br><br>Regular</h2>
            <p>Acesse a Matéria</p>
        </div>
    </a>
</div>
</div>
</div>

<footer class="bg-dark text-light text-center py-3">
    <div class="container">
        <p>&copy; 2024 Time Flies. Todos os direitos reservados.</p>
    </div>
</footer>

<script src="script1.js"></script>
<script src="../login/sessionTimeout.js"></script>
<script>
        // Função para formatar o tempo em HH:MM:SS
        function formatarTempo(segundos) {
            var horas = Math.floor(segundos / 3600);
            var minutos = Math.floor((segundos % 3600) / 60);
            var segundos = segundos % 60;

            return `${horas.toString().padStart(2, '0')}:${minutos.toString().padStart(2, '0')}:${segundos.toString().padStart(2, '0')}`;
        }

        // Inicializa o contador de tempo
        var tempoSessao = 0;
        var tempoSessaoElemento = document.getElementById('tempo-sessao');

        // Atualiza o contador de tempo a cada segundo
        setInterval(function() {
            tempoSessao++;
            tempoSessaoElemento.textContent = formatarTempo(tempoSessao);
        }, 1000);
    </script>

</body>
</html>
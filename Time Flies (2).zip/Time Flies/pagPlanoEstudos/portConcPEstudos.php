<?php
require_once "../login/verificarLogin.php";
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

$conexao = new mysqli($servername, $username, $password, $dbname);

if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    for ($i = 1; $i <= 20; $i++) {
        $data = $_POST["data_$i"] ?? '';
        $conteudo = $_POST["conteudo_$i"] ?? '';
        $status = $_POST["status_$i"] ?? '';
        $materia = "Português Regular";

        if (!empty($data) && !empty($conteudo) && !empty($status)) {
            $sql = "REPLACE INTO plano_estudo (id, data, conteudo, status, materia) VALUES ($i, '$data', '$conteudo', '$status', '$materia')";
            if (!$conexao->query($sql)) {
                echo "Erro ao salvar dados: " . $conexao->error;
            }
        }
    }
}

// Recupera os dados do BD
$sql = "SELECT * FROM plano_estudo";
$result = $conexao->query($sql);

// Armazena os dados recuperados
$dados = [];

// Calcula a quantidade de matérias por status
$statusCount = ["Pendente" => 0, "Concluído" => 0, "Em andamento" => 0];

if ($result->num_rows > 0) {
    // Percorre os dados e armazena-os no array
    while ($row = $result->fetch_assoc()) {
        $dados[$row['id']] = $row;
        // Calcula a quantidade de matérias por status
        $statusCount[$row['status']]++;
    }
}

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TF-Plano de Estudos</title>
    <link rel="stylesheet" href="">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
<style>
body {
    background: linear-gradient(135deg, #82DFD6, #06A7BF);
    background-image: url("");
    font-weight: bold;
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    font-family: 'Roboto', sans-serif;
    text-align: center;
    margin: 0;
}

.progress {
    width: 100%;
    background-color: #f3f3f3;
    border-radius: 20px;
    margin-bottom: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    overflow: hidden; 
}

.progress-bar {
    width: <?php echo round(($statusCount['Concluído'] / 20) * 100); ?>%;
    height: 20px; 
    background: linear-gradient(45deg, #4caf50, #2e7d32); 
    text-align: center;
    line-height: 40px;
    color: white;
    border-radius: 20px;
    transition: width 0.5s; 
    font-size: 12px;
    padding-right: 5px; 
}

.progress-bar:hover {
    width: calc(<?php echo round(($statusCount['Concluído'] / 20) * 100); ?>% + 10px); 
}

table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

table th,
table td {
    padding: 12px;
    border: 1px solid #ddd;
}

table th {
    background-color: #f2f2f2;
    font-weight: bold;
}

form {
    margin-top: 20px;
}

form input[type="date"],
form textarea,
form select {
    width: calc(100% - 24px); 
    padding: 12px;
    border-radius: 5px;
    border: 1px solid #ccc;
    margin-bottom: 10px;
    font-size: 16px;
    box-sizing: border-box;
}

form button {
    color: #fff;
    font-weight: bold;
    font-size: 16px;
    border-radius: 30px;
    padding: 12px 20px;
    width: 100%;
    background-color: #007bff;
    border: 2px solid #007bff;
    cursor: pointer;
    transition: background-color 0.3s, border-color 0.3s;
}

form button:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}

.mensagem {
    color: #fff;
    font-weight: bold;
    margin-top: 10px;
    padding: 12px;
    border-radius: 5px;
}

.mensagem.erro {
    background-color: #dc3545;
}

.mensagem.sucesso {
    background-color: #28a745;
}
</style>
</head>
<body>
</br>
</br>
<div class="container">
  <h1>Plano de Estudo - Português Regular</h1>
  </br>
  <div class="estatisticas">
    <p>Quantidade de matérias pendentes: <?php echo $statusCount['Pendente']; ?></p>
    <p>Quantidade de matérias concluídas: <?php echo $statusCount['Concluído']; ?></p>
    <p>Quantidade de matérias em andamento: <?php echo $statusCount['Em andamento']; ?></p>
    <a href="../pagMaterias/portugues.php" class="btn btn-info"><strong>Voltar</strong></a>
    <br><br>
    <div class="progress">
      <div class="progress-bar"><?php echo round(($statusCount['Concluído'] / 20) * 100); ?>%</div>
    </div>
  </div>

  <form id="planoEstudoForm" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
    <table>
      <thead>
        <tr>
          <th>Aula</th>
          <th>Data</th>
          <th>Conteúdo</th>
          <th>Status</th>
          <th>Matéria</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody id="planoEstudoBody">
        <?php 
        // Exibe as linhas com os dados recuperados do banco de dados
        for ($i = 1; $i <= 20; $i++) { 
            $data = $dados[$i]['data'] ?? '';
            $conteudo = $dados[$i]['conteudo'] ?? '';
            $status = $dados[$i]['status'] ?? '';
            ?>
            <tr>
                <td><?php echo $i; ?></td>
                <td><input type="date" name="data_<?php echo $i; ?>" value="<?php echo $data; ?>"></td>
                <td><textarea name="conteudo_<?php echo $i; ?>"><?php echo $conteudo; ?></textarea></td>
                <td>
                    <select name="status_<?php echo $i; ?>">
                        <option value="Pendente" <?php if($status == 'Pendente') echo 'selected'; ?>>Pendente</option>
                        <option value="Concluído" <?php if($status == 'Concluído') echo 'selected'; ?>>Concluído</option>
                        <option value="Em andamento" <?php if($status == 'Em andamento') echo 'selected'; ?>>Em andamento</option>
                    </select>
                </td>
                <td>Português Regular</td>
                <td>
                    <button type="submit" class="btn">Salvar</button>
                </td>
            </tr>
        <?php } ?>
      </tbody>
    </table>
    <div id="mensagem" class="mensagem"></div>
  </form>
</div>

<script>
document.addEventListener("DOMContentLoaded", function() {
  const mensagemDiv = document.getElementById("mensagem");

  // Função para mostrar mensagem na página
  function mostrarMensagem(type, message) {
    mensagemDiv.textContent = message;
    mensagemDiv.className = `mensagem ${type}`;
    setTimeout(() => {
      mensagemDiv.textContent = "";
      mensagemDiv.className = "mensagem";
    }, 5000); // Remove a mensagem após 5 segundos
  }

  // Exibir mensagem de sucesso ou erro após envio do formulário
  const mensagem = "<?php echo isset($_GET['mensagem']) ? $_GET['mensagem'] : ''; ?>";
  const tipoMensagem = "<?php echo isset($_GET['tipo']) ? $_GET['tipo'] : ''; ?>";
  if (mensagem !== '') {
    mostrarMensagem(tipoMensagem, mensagem);
  }
});
</script>
<footer class="bg-dark text-light text-center py-3">
    <div class="container">
        <p>&copy; 2024 Time Flies. Todos os direitos reservados.</p>
    </div>
</footer>
</body>
</html>
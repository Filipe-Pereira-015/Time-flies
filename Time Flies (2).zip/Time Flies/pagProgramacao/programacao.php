<?php
require_once "../login/verificarLogin.php";
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

$conexao = new mysqli($servername, $username, $password, $dbname);

if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

// Data atual
$data_atual = date('Y-m-d');

// Data após 7 dias
$data_futura = date('Y-m-d', strtotime('+7 days', strtotime($data_atual)));

// Consulta SQL para obter os agendamentos nos próximos 7 dias
$sql = "SELECT * FROM agendamento WHERE data BETWEEN '$data_atual' AND '$data_futura' ORDER BY data";

$result = $conexao->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TF-Programação</title>
    <link rel="stylesheet" href="StyleMaterias.css">
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
    <title>Programação de: <?php echo date('d/m/Y', strtotime($data_atual)) . ' - ' . date('d/m/Y', strtotime($data_futura)); ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1 class="text-center mt-5 mb-4">Programação de: <?php echo date('d/m/Y', strtotime($data_atual)) . ' - ' . date('d/m/Y', strtotime($data_futura)); ?></h1>
        </br>
        <a href="#" class="btn btn-info" onclick="location.reload(true);"><strong>Atualizar Página</strong></a>
        <a href="../pagInicial/pagInicial.php" class="btn btn-info"><strong>Voltar</strong></a>
        </br></br>

        <?php
        $data_atual_exibida = null;
        while ($row = $result->fetch_assoc()): 
            $data_agendamento = date('Y-m-d', strtotime($row['data']));
            if ($data_agendamento != $data_atual_exibida) {
                if ($data_atual_exibida !== null) {
                    echo "</tbody></table>";
                }
                $data_atual_exibida = $data_agendamento;
                echo "<h3 class='mt-5'>" . date('l - d/m/Y', strtotime($data_atual_exibida)) . "</h3>";
                echo "<table class='table table-striped mt-3'>";
                echo "<thead class='thead-dark'>
                        <tr>
                            <th scope='col'>Conteúdo</th>
                            <th scope='col'>Status</th>
                            <th scope='col'>Matéria</th>
                        </tr>
                    </thead>
                    <tbody>";
            }
            echo "<tr>
                    <td>" . htmlspecialchars($row['conteudo']) . "</td>
                    <td>" . htmlspecialchars($row['status']) . "</td>
                    <td>" . htmlspecialchars($row['materia']) . "</td>
                </tr>";
        endwhile; 
        if ($result->num_rows == 0 || $data_agendamento != $data_atual_exibida) {
            echo "<tr><td colspan='3' class='text-center'>Sem programação para este dia.</td></tr>";
        }
        ?>
        </tbody>
        </table>
    </div>
    <footer class="bg-dark text-light text-center py-3">
    <div class="container">
        <p>&copy; 2024 Time Flies. Todos os direitos reservados.</p>
    </div>
</footer>
</body>
</html>

<?php

$conexao->close();
?>
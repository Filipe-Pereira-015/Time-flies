<?php
require_once "../login/verificarLogin.php";
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

$conexao = new mysqli($servername, $username, $password, $dbname);

if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

// Função para obter os dados da matéria 'portugues-regular'
function obterDadosPortugues($conexao) {
    $sql = "SELECT SUM(total_questoes) AS total_questoes, SUM(acertos) AS total_acertos, SUM(erradas) AS total_erradas FROM questoes WHERE materia = 'portugues-regular'";
    $resultado = $conexao->query($sql);

    if ($resultado && $resultado->num_rows > 0) {
        $row = $resultado->fetch_assoc();
        return [
            'total_questoes' => $row['total_questoes'],
            'total_acertos' => $row['total_acertos'],
            'total_erradas' => $row['total_erradas']
        ];
    } else {
        return [
            'total_questoes' => 0,
            'total_acertos' => 0,
            'total_erradas' => 0
        ];
    }
}

// Inicialização dos dados
$dadosPortugues = obterDadosPortugues($conexao);
$quantidadeTotal = $dadosPortugues['total_questoes'];
$quantidadeAcertos = $dadosPortugues['total_acertos'];
$quantidadeErradas = $dadosPortugues['total_erradas'];

// Calcular o progresso percentual
$progresso = ($quantidadeTotal > 0) ? ($quantidadeAcertos / $quantidadeTotal) * 100 : 0;
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Time Flies - Português para Concursos</title>
    <link rel="stylesheet" href="StyleMaterias.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">

        <!-- Gráfico de Progresso -->
        <div class="card">
            <h1>PORTUGUÊS PARA CONCURSOS</h1>
            <div class="progress-bar">
                <div class="progress-bar-fill"></div>
                <div class="progress-bar-text">Progresso: <?= number_format($progresso, 2) ?>%</div>
            </div>
            <div class="btn-group">
            <a href="../pagInicial/pagInicial.php" class="btn btn-info"><strong><<</strong></a>
                <a href="../index.html" class="btn btn-info">Página Inicial</a>
                <a href="../login/login.php" class="btn btn-danger">Encerrar Sessão</a>
        </div>
        </div>
<br>
        </div>
        <!-- Gráfico de Barras -->
        <div class="card">
        <div class="btn-group">
        <a href="../PagPlanoEstudos/portConcPEstudos.php" class="btn btn-info">Plano de Estudo</a>
        </div>
            <h3>Estatísticas</h3>
            <canvas id="barChart" width="400" height="200"></canvas>
        </div>

        <!-- Gráfico de Linha -->
        <div class="card">
            <h3>Progresso ao Longo do Tempo</h3>
            <canvas id="lineChart" width="400" height="200"></canvas>
        </div>

        <!-- Gráfico de Pizza -->
        <div class="card">
            <h3>Distribuição de Acertos e Erros</h3>
            <canvas id="pieChart" width="400" height="200"></canvas>
        </div>
        
    </div>
    <script>
        // Função para atualizar os dados
        function atualizarDados() {
            var dadosAtualizados = {
                total_questoes: Math.floor(Math.random() * 100) + 1,
                total_acertos: Math.floor(Math.random() * 100),
                total_erradas: Math.floor(Math.random() * 100)
            };
            
            // Atualiza os gráficos com os novos dados
            atualizarGraficos(dadosAtualizados);
        }

        // Função para atualizar os gráficos com os novos dados
        function atualizarGraficos(novosDados) {
            // Atualiza o gráfico de barras
            barChart.data.datasets[0].data = [novosDados.total_questoes, novosDados.total_acertos, novosDados.total_erradas];
            barChart.update();

            // Atualiza o gráfico de linha
            var novoValor = Math.floor(Math.random() * 100) + 1;
            lineChart.data.datasets[0].data.push(novoValor);
            lineChart.update();

            // Atualiza o gráfico de pizza
            var novosAcertos = Math.floor(Math.random() * 100);
            var novosErros = Math.floor(Math.random() * 100);
            pieChart.data.datasets[0].data = [novosAcertos, novosErros];
            pieChart.update();
        }

        // Script para renderizar o gráfico de barras
        var ctxBar = document.getElementById('barChart').getContext('2d');
        var barChart = new Chart(ctxBar, {
            type: 'bar',
            data: {
                labels: ['Total de Questões', 'Questões Corretas', 'Questões Erradas'],
                datasets: [{
                    label: 'Progresso',
                    data: [<?= $quantidadeTotal ?>, <?= $quantidadeAcertos ?>, <?= $quantidadeErradas ?>],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Script para renderizar o gráfico de linha
        var ctxLine = document.getElementById('lineChart').getContext('2d');
        var lineChart = new Chart(ctxLine, {
            type: 'line',
            data: {
                labels: ['Semana 1', 'Semana 2', 'Semana 3', 'Semana 4'],
                datasets: [{
                    label: 'Progresso Semanal',
                    data: [50, 60, 70, 80],
                    fill: false,
                    borderColor: 'rgba(75, 192, 192, 1)',
                    tension: 0.1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Script para renderizar o gráfico de pizza
        var ctxPie = document.getElementById('pieChart').getContext('2d');
        var pieChart = new Chart(ctxPie, {
            type: 'pie',
            data: {
                labels: ['Acertos', 'Erros'],
                datasets: [{
                    label: 'Distribuição de Acertos e Erros',
                    data: [<?= $quantidadeAcertos ?>, <?= $quantidadeErradas ?>],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 99, 132, 0.2)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 99, 132, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
    <footer class="bg-dark text-light text-center py-3">
    <div class="container">
        <p>&copy; 2024 Time Flies. Todos os direitos reservados.</p>
    </div>
</footer>
</body>
</html>
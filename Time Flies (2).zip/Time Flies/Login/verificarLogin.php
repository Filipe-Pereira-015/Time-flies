<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

$conexao = new mysqli($servername, $username, $password, $dbname);

if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

$usuarioLogado = isset($_SESSION['usuario_id']);

if (!$usuarioLogado) {
    session_destroy();
    header("Location: ../login/login.php");
    exit;
}

if (!isset($_SESSION['cpf'])) {
    $cpfUsuario = buscarCpfUsuario($_SESSION['usuario_id']);
    $_SESSION['cpf'] = $cpfUsuario; 
} else {
    $cpfUsuario = $_SESSION['cpf'];
}

function buscarCpfUsuario($usuario_id) {
    global $conexao;

    $sql = "SELECT cpf FROM Usuarios WHERE usuario_id = $usuario_id";
    $result = $conexao->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['cpf'];
    } else {
        return null;
    }
}
?>
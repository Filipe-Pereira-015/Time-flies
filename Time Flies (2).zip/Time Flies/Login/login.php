<?php
session_start();

if (isset($_SESSION['mensagem_erro'])) {
    echo '<div class="alert alert-danger" role="alert">' . $_SESSION['mensagem_erro'] . '</div>';
    unset($_SESSION['mensagem_erro']); // Irá Limpar a mensagem de erro para que não seja exibida novamente.
}
?>
<!DOCTYPE html>
<html lang="PT-BR">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
    <link rel="stylesheet" href="stylelogin.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="centered">
    <img src="../img/icon1.png" alt="Logo" class="logo">
        <h1 class="text-3d">Entrar - Time Flies</h1>
        <div class="card">
            <form method="post" action="processar_login.php">
                <input type="text" name="cpf" placeholder="CPF Cadastrado" required>
                <input type="password" name="senha" placeholder="Senha de Usuário" required>
                <div class="button-group">
                    <input type="submit" value="Entrar" class="btn">
                    <a href="../index.html" class="btn">Página Inicial</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
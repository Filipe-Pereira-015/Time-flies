<?php
session_start();

// Conexão com o Banco de Dados Time_fliesgerenciador
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

// Estabelece a conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cpf = $_POST['cpf'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM usuarios WHERE cpf = '$cpf' AND senha = '$senha'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if ($user['bloqueado'] == 1) {
            $_SESSION['mensagem_erro'] = "Usuário bloqueado. Não é possível efetuar o login.";
        } else {
            // Se a autenticação for bem-sucedida, redireciona para a página de estudo.
            $_SESSION['usuario_id'] = $user['usuario_id'];
            header("Location: ../paginicial/paginicial.php");
            exit();
        }
    } else {
        $_SESSION['mensagem_erro'] = "CPF ou senha inválidos. Tente novamente!";
    }
}

header("Location: login.php");
exit();
?>
<?php
// Conexão com o Banco de Dados Time_fliesgerenciador
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

// Estabelece a conexão
$conexao = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

// Diretório de destino para os uploads
$diretorio_destino = 'anexos/';

// Verifica se o arquivo foi enviado sem erros
if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
    // Extrai informações sobre o arquivo enviado
    $nome_arquivo = $_FILES['file']['name'];
    $caminho_temporario = $_FILES['file']['tmp_name'];

    // Move o arquivo para o diretório de destino
    if (move_uploaded_file($caminho_temporario, $diretorio_destino . $nome_arquivo)) {
        // Verifica se uma observação foi fornecida
        $observacao = isset($_POST['observacao']) ? $_POST['observacao'] : '';

        // Verifica se uma matéria foi fornecida
        $materia = isset($_POST['materia']) ? $_POST['materia'] : '';

        // Salva a observação em um arquivo de texto com o mesmo nome do arquivo enviado
        $caminho_observacao = $diretorio_destino . pathinfo($nome_arquivo, PATHINFO_FILENAME) . '.txt';
        file_put_contents($caminho_observacao, $observacao);

        // Insere as informações do arquivo no banco de dados usando instruções preparadas
        $sql = "INSERT INTO anexos (nome_arquivo, caminho_arquivo, tamanho, tipo_mime, observacao, materia, data_upload) 
                VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

        $stmt = $conexao->prepare($sql);
        $stmt->bind_param("ssdsss", $nome_arquivo, $caminho_destino, $tamanho_arquivo, $tipo_mime, $observacao, $materia);

        // Define os parâmetros e executa a instrução preparada
        $caminho_destino = $diretorio_destino . $nome_arquivo;
        $tamanho_arquivo = filesize($diretorio_destino . $nome_arquivo);
        $tipo_mime = mime_content_type($diretorio_destino . $nome_arquivo);

        if ($stmt->execute()) {
            // Redireciona de volta para a página anterior
            header("Location: {$_SERVER['HTTP_REFERER']}");
            exit();
        } else {
            echo "Erro ao inserir no banco de dados: " . $stmt->error;
        }
    } else {
        echo "Ocorreu um erro ao enviar o arquivo.";
    }
} else {
    echo "Erro no envio do arquivo.";
}

// Fecha a conexão
$conexao->close();
?>

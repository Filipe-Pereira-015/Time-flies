<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

// Função para obter a última data de download do arquivo
function getLastDownloadDate($filename, $conexao)
{
    // Query para buscar a última data de download do arquivo no banco de dados
    $query = "SELECT data_download FROM downloads WHERE nome_arquivo = '$filename' ORDER BY data_download DESC LIMIT 1";

    // Executa a query
    $result = $conexao->query($query);

    // Verifica se a query foi executada com sucesso
    if ($result) {
        // Verifica se foram encontrados registros
        if ($result->num_rows > 0) {
            // Obtém a última data de download do arquivo
            $row = $result->fetch_assoc();
            return date("d/m/Y", strtotime($row["data_download"]));
        } else {
            // Se não houver registros, retorna uma mensagem indicando que nunca foi baixado
            return "Nunca baixado";
        }
    } else {
        // Se houver um erro na execução da query, retorna uma mensagem de erro
        return "Erro ao obter data de download";
    }
}

// Estabelece a conexão com o banco de dados
$conexao = new mysqli($servername, $username, $password, $dbname);

// Verifica a conexão
if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}
?>

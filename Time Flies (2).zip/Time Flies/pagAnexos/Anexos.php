<?php
require_once "../login/verificarLogin.php";
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TF-Anexos</title>
    <link rel="stylesheet" href="StyleAnexos.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
</head>

<body>
    <div class="container">
        <img src="../img/icon.jpg" alt="Logo" class="logo">
        <h3>Anexar Arquivos/Conteúdos</h3>

        <!-- Formulário para upload de anexos -->
        <div class="form-container">
            <form action="upload.php" method="post" enctype="multipart/form-data">
                <label for="file">Selecione um arquivo para upload:</label>
                <input type="file" name="file" id="file" required>
                <div class="observacao">
                    <label for="observacao">Observação:</label>
                    <textarea name="observacao" id="observacao" rows="4" cols="50"
                        placeholder="Adicione uma observação"></textarea>
                </div>
                <label for="materia">Selecione a matéria:</label>
                <select name="materia" id="materia" required>
                    <option value="">Selecione a matéria</option>
                    <option value="Português">Português</option>
                    <option value="Matemática">Matemática</option>
                    <option value="Informática">Informática</option>
                    <option value="Direito Constitucional">Direito Constitucional</option>
                    <option value="Direito Administrativo">Direito Administrativo</option>
                    <option value="Legislação">Legislação</option>
                    <option value="Raciocínio Lógico">Raciocínio Lógico</option>
                    <option value="Direito Penal">Direito Penal</option>
                    <option value="Direito Civil">Direito Civil</option>
                    <option value="Conhecimentos Gerais">Conhecimentos Gerais</option>
                    <option value="Matemática Regular">Matemática Regular</option>
                    <option value="História Regular">História Regular</option>
                    <option value="Geografia Regular">Geografia Regular</option>
                    <option value="Física Regular">Física Regular</option>
                    <option value="Química Regular">Química Regular</option>
                    <option value="Biologia Regular">Biologia Regular</option>
                    <option value="Não se Aplica">Não se Aplica</option>
                </select>
                <button type="submit" name="submit">Enviar</button>
            </form>
            <a href="../pagInicial/pagInicial.php" class="btn btn-info"><strong><<</strong></a>
            <a href="#" class="btn center-btn" onclick="location.reload(true);"><strong>Atualizar Página</strong></a>
            <a href="../index.html" class="btn btn-info">Página Inicial</a>
            <a href="../login/login.php" class="btn btn-danger">Encerrar Sessão</a>
        </div>

        <!-- Filtros -->
        <div class="filters-container">
            <label for="filter">Filtrar por matéria:</label>
            <select name="filter" id="filter">
                <option value="all">Todas as matérias</option>
                <option value="Português">Português</option>
                <option value="Matemática">Matemática</option>
                <option value="Informática">Informática</option>
                <option value="Direito Constitucional">Direito Constitucional</option>
                <option value="Direito Administrativo">Direito Administrativo</option>
                <option value="Legislação">Legislação</option>
                <option value="Raciocínio Lógico">Raciocínio Lógico</option>
                <option value="Direito Penal">Direito Penal</option>
                <option value="Direito Civil">Direito Civil</option>
                <option value="Conhecimentos Gerais">Conhecimentos Gerais</option>
                <option value="Matemática Regular">Matemática Regular</option>
                <option value="História Regular">História Regular</option>
                <option value="Geografia Regular">Geografia Regular</option>
                <option value="Física Regular">Física Regular</option>
                <option value="Química Regular">Química Regular</option>
                <option value="Biologia Regular">Biologia Regular</option>
                <option value="Não se Aplica">Não se Aplica</option>
            </select>
            <label for="date-filter">Filtrar por data:</label>
            <input type="date" id="date-filter">
            <input type="text" class="search-box" id="search" placeholder="Pesquisar por nome do arquivo">
        </div>

        <hr>

        <!-- Lista de anexos disponíveis para download -->
        <h3>Anexos Disponíveis:</h3>
        <ul>
            <?php
            // Diretório onde os anexos estão armazenados
            $diretorio = 'anexos/';

            // Verifica se o diretório existe
            if (is_dir($diretorio)) {
                // Abre o diretório
                if ($dh = opendir($diretorio)) {
                    // Loop através dos arquivos no diretório
                    while (($file = readdir($dh)) !== false) {
                        // Exclui arquivos ocultos e o diretório pai
                        if ($file != '.' && $file != '..') {
                            // Obtém informações do arquivo
                            $caminho_arquivo = $diretorio . $file;
                            $data_upload = date("d/m/Y", filemtime($caminho_arquivo));
                            $tamanho_arquivo = filesize($caminho_arquivo);

                            // Obtém a observação do arquivo, se existir
                            $observacao = '';
                            $caminho_observacao = $diretorio . pathinfo($file, PATHINFO_FILENAME) . '.txt';
                            if (file_exists($caminho_observacao)) {
                                $observacao = file_get_contents($caminho_observacao);
                            }

                            // Obtém a matéria do arquivo, se existir
                            $materia = '';
                            $filename_parts = explode('-', $file);
                            if (count($filename_parts) > 1) {
                                $materia = trim($filename_parts[0]);
                            }

                            // Exibe as informações do arquivo
                            echo "<li class='file-item' data-materia='$materia'>";
                            echo "<div class='anexo-info'><strong>Nome do Arquivo:</strong> $file</div>";
                            echo "<div class='anexo-info'><strong>Data de Upload:</strong> $data_upload</div>";
                            echo "<div class='anexo-info'><strong>Tamanho:</strong> " . formatBytes($tamanho_arquivo) . "</div>";
                            echo "<div class='anexo-info'><strong>Observação:</strong> $observacao</div>";
                            echo "<a href='$caminho_arquivo' class='download-button' download>Download</a>";
                            echo "</li>";
                        }
                    }
                    closedir($dh);
                }
            }

            // Função para formatar o tamanho do arquivo em bytes para uma string legível
            function formatBytes($bytes, $precision = 2)
            {
                $units = array('B', 'KB', 'MB', 'GB', 'TB');

                $bytes = max($bytes, 0);
                $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
                $pow = min($pow, count($units) - 1);

                return round($bytes, $precision) . ' ' . $units[$pow];
            }
            ?>
        </ul>
    </div>

    <script>
        // Filtrar anexos por matéria
        document.getElementById('filter').addEventListener('change', function() {
            var filterValue = this.value.toLowerCase();
            var liItems = document.querySelectorAll('.file-item');
            liItems.forEach(function(item) {
                var materia = item.dataset.materia.toLowerCase();
                if (filterValue === 'all' || materia.includes(filterValue)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });

        // Filtrar anexos por data
        document.getElementById('date-filter').addEventListener('input', function() {
            var dateValue = this.value;
            var liItems = document.querySelectorAll('.file-item');
            liItems.forEach(function(item) {
                var dataUpload = item.querySelector('.anexo-info strong:nth-of-type(3)').textContent.trim();
                if (!dateValue || dataUpload === dateValue) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });

        // Pesquisar anexos por nome do arquivo
        document.getElementById('search').addEventListener('input', function() {
            var searchValue = this.value.toLowerCase();
            var liItems = document.querySelectorAll('.file-item');
            liItems.forEach(function(item) {
                var filename = item.querySelector('.anexo-info strong').nextSibling.textContent.toLowerCase();
                if (filename.includes(searchValue)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html>
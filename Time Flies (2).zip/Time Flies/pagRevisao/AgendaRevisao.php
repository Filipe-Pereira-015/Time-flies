<?php
require_once "../login/verificarLogin.php";
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

$conexao = new mysqli($servername, $username, $password, $dbname);

if ($conexao->connect_error) {
    die("Conexão falhou: " . $conexao->connect_error);
}

// Função para exibir mensagens
function mostrarMensagem($mensagem, $tipo = 'info') {
    echo "<div class='alert alert-$tipo' role='alert'>$mensagem</div>";
}

// Verifica se foi enviado um pedido de agendamento
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['agendar'])) {
    $data = $_POST["data"];
    $conteudo = $_POST["conteudo"];
    $status = $_POST["status"];
    $materia = $_POST["materia"];

    // Verifica se todos os campos foram preenchidos
    if (!empty($data) && !empty($conteudo) && !empty($status) && !empty($materia)) {
        $numero_agendamento = uniqid('AGD');

        $stmt = $conexao->prepare("INSERT INTO agendamento (data, conteudo, status, materia, numero_agendamento) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $data, $conteudo, $status, $materia, $numero_agendamento);
        
        // Executa a inserção no banco de dados
        if ($stmt->execute()) {
            mostrarMensagem("Revisão agendada com sucesso.", 'success');
        } else {
            mostrarMensagem("Erro ao agendar revisão: " . $stmt->error, 'danger');
        }
        $stmt->close();
    } else {
        mostrarMensagem("Todos os campos devem ser preenchidos.", 'warning');
    }
}

// Verifica se foi enviado um pedido para editar o status do agendamento
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['editar_status'])) {
    $agendamento_id = $_POST["agendamento_id"];
    $novo_status = $_POST["status"];

    $stmt = $conexao->prepare("UPDATE agendamento SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $novo_status, $agendamento_id);

    // Executa a atualização no banco de dados
    if ($stmt->execute()) {
        mostrarMensagem("Status do agendamento atualizado com sucesso.", 'success');
    } else {
        mostrarMensagem("Erro ao atualizar o status do agendamento: " . $stmt->error, 'danger');
    }
    $stmt->close();
}

// Consulta SQL para selecionar todos os agendamentos
$sql = "SELECT * FROM agendamento WHERE 1=1";

// Verifica se foram enviados filtros de pesquisa por GET e os aplica na consulta SQL
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (!empty($_GET['numero_agendamento'])) {
        $numero_agendamento = $_GET["numero_agendamento"];
        $sql .= " AND numero_agendamento = '$numero_agendamento'";
    }
    if (!empty($_GET['materia'])) {
        $materia = $_GET["materia"];
        $sql .= " AND materia = '$materia'";
    }
    if (!empty($_GET['status'])) {
        $status = $_GET["status"];
        $sql .= " AND status = '$status'";
    }
    if (!empty($_GET['data'])) {
        $data = $_GET["data"];
        $sql .= " AND data = '$data'";
    }
}

// Executa a consulta SQL
$result = $conexao->query($sql);

// Consulta SQL para selecionar todas as matérias para os filtros
$query_materias = "SELECT DISTINCT materia FROM agendamento";
$result_materias = $conexao->query($query_materias);

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
</head>
<body>
    <div class="container">
        <h1 class="text-center mt-5 mb-4">Agendamento</h1>

        <!-- Formulário para adicionar novo agendamento -->
        <form id="formNovoAgendamento" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <!-- Campos do formulário -->
            <div class="form-row">
                <div class="form-group col-md-4">
                    <label for="data">Data:</label>
                    <input type="date" id="data" name="data" class="form-control" required>
                </div>
                <div class="form-group col-md-4">
                    <label for="conteudo">Conteúdo:</label>
                    <input type="text" id="conteudo" name="conteudo" class="form-control" required>
                </div>
                <div class="form-group col-md-4">
                    <label for="materia">Matéria:</label>
                    <select id="materia" name="materia" class="form-control" required>
                        <option value="">Selecione a matéria</option>
                        <option value="Português">Português</option>
                        <option value="Matemática">Matemática</option>
                        <option value="Informática">Informática</option>
                        <option value="Direito Constitucional">Direito Constitucional</option>
                        <option value="Direito Administrativo">Direito Administrativo</option>
                        <option value="Legislação">Legislação</option>
                        <option value="Raciocínio Lógico">Raciocínio Lógico</option>
                        <option value="Direito Penal">Direito Penal</option>
                        <option value="Direito Civil">Direito Civil</option>
                        <option value="Conhecimentos Gerais">Conhecimentos Gerais</option>
                        <option value="Matemática Regular">Matemática Regular</option>
                        <option value="História Regular">História Regular</option>
                        <option value="Geografia Regular">Geografia Regular</option>
                        <option value="Física Regular">Física Regular</option>
                        <option value="Química Regular">Química Regular</option>
                        <option value="Biologia Regular">Biologia Regular</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="status">Status:</label>
                <select id="status" name="status" class="form-control" required>
                    <option value="">Selecione o status</option>
                    <option value="Revisão agendada">Revisão agendada</option>
                    <option value="Estudo agendado">Estudo agendado</option>
                    <option value="Revisão/Estudo agendado em andamento">Revisão/Estudo agendado em andamento</option>
                    <option value="Pendente">Pendente</option>
                    <option value="Concluída">Concluída</option>
                </select>
            </div>
            <!-- Botão para adicionar agendamento -->
            <button type="submit" name="agendar" class="btn btn-primary btn-lg">Agendar</button>
            <!-- Link para voltar -->
            <a href="../pagInicial/pagInicial.php" class="btn btn-info"><strong>Voltar</strong></a>
        </form>

        <!-- Formulário para filtrar agendamentos -->
        <form class="mb-5" method="get" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-row">
                <!-- Campos de filtragem -->
                <div class="form-group col-md-4">
                    <label for="numero_agendamento">Pesquisar por Número de Agendamento:</label>
                    <input type="text" id="numero_agendamento" name="numero_agendamento" class="form-control">
                </div>
                <div class="form-group col-md-4">
                    <label for="materia_filtro">Filtrar por Matéria:</label>
                    <select id="materia_filtro" name="materia" class="form-control">
                        <option value="">Todas as matérias</option>
                        <?php
                        // Preenche o filtro de matérias
                        if ($result_materias->num_rows > 0) {
                            $result_materias->data_seek(0);
                            while ($row_materia = $result_materias->fetch_assoc()) {
                                echo "<option value='" . htmlspecialchars($row_materia['materia']) . "'>" . htmlspecialchars($row_materia['materia']) . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="status_filtro">Filtrar por Status:</label>
                    <select id="status_filtro" name="status" class="form-control">
                        <option value="">Todos os status</option>
                        <option value="Revisão agendada">Revisão agendada</option>
                        <option value="Estudo agendado">Estudo agendado</option>
                        <option value="Revisão/Estudo agendado em andamento">Revisão/Estudo agendado em andamento</option>
                        <option value="Pendente">Pendente</option>
                        <option value="Concluída">Concluída</option>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="data_filtro">Filtrar por Data:</label>
                    <input type="date" id="data_filtro" name="data" class="form-control">
                </div>
            </div>
            <!-- Botão para pesquisar -->
            <div class="form-group">
                <button type="submit" class="btn btn-outline-secondary">Pesquisar</button>
            </div>
        </form>

        <!-- Tabela para exibir os agendamentos -->
        <div class="table-responsive">
            <table class="table table-striped">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Data</th>
                        <th scope="col">Conteúdo</th>
                        <th scope="col">Status</th>
                        <th scope="col">Matéria</th>
                        <th scope="col">Número de Agendamento</th>
                        <th scope="col">Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Exibe os agendamentos encontrados na tabela
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['data']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['conteudo']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['materia']) . "</td>";
                            echo "<td>" . htmlspecialchars($row['numero_agendamento']) . "</td>";
                            // Formulário para editar o status do agendamento
                            echo "<td><form method='post' action='".htmlspecialchars($_SERVER["PHP_SELF"])."'>";
                            echo "<input type='hidden' name='agendamento_id' value='" . htmlspecialchars($row['id']) . "'>";
                            echo "<select name='status' class='form-control-sm'>";
                            echo "<option value='Revisão agendada'>Revisão agendada</option>";
                            echo "<option value='Estudo agendado'>Estudo agendado</option>";
                            echo "<option value='Revisão/Estudo agendado em andamento'>Revisão/Estudo agendado em andamento</option>";
                            echo "<option value='Pendente'>Pendente</option>";
                            echo "<option value='Concluída'>Concluída</option>";
                            echo "</select>";
                            echo "<button type='submit' name='editar_status' class='btn btn-primary btn-sm mt-1'>Salvar</button></form></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='7'>Nenhum agendamento encontrado.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <footer class="bg-dark text-light text-center py-3">
    <div class="container">
        <p>&copy; 2024 Time Flies. Todos os direitos reservados.</p>
    </div>
</footer>
</body>
</html>

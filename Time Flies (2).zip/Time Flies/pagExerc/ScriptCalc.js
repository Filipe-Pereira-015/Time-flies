  // Calcula a quantidade de erros e exibir um gráfico
  document.getElementById("formExercicios").addEventListener("submit", function(event) {
    event.preventDefault(); // Evitar o envio do formulário
    var totalExercicios = parseInt(document.getElementById("totalExercicios").value);
    var exerciciosCorretos = parseInt(document.getElementById("exerciciosCorretos").value);
    
    // Validar entrada para garantir que os valores sejam números positivos
    if (isNaN(totalExercicios) || isNaN(exerciciosCorretos) || totalExercicios < 0 || exerciciosCorretos < 0) {
      alert("Por favor, insira valores válidos para os exercícios.");
      return;
    }
    
    var exerciciosErrados = totalExercicios - exerciciosCorretos;
    var percentualAcertos = (exerciciosCorretos / totalExercicios) * 100;
    var mediaAcertosPorExercicio = exerciciosCorretos / totalExercicios;
    var percentualErros = (exerciciosErrados / totalExercicios) * 100;
    
    // Exibir os resultados de forma mais detalhada
    document.getElementById("resultado").innerHTML = "<p>Quantidade de exercícios feitos: " + totalExercicios + "</p>" +
                                                      "<p>Quantidade de exercícios acertados: " + exerciciosCorretos + "</p>" +
                                                      "<p>Quantidade de erros: " + exerciciosErrados + "</p>" +
                                                      "<p>Porcentagem de acertos: " + percentualAcertos.toFixed(2) + "%</p>" +
                                                      "<p>Média de acertos por exercício: " + mediaAcertosPorExercicio.toFixed(2) + "</p>" +
                                                      "<p>Porcentagem de erros em relação ao total de exercícios: " + percentualErros.toFixed(2) + "%</p>";
    
    // Desenhar o gráfico de barras
    var ctx = document.getElementById("grafico").getContext('2d');
    var myChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ["Acertos", "Erros"],
        datasets: [{
          label: 'Quantidade de Acertos e Erros',
          data: [exerciciosCorretos, exerciciosErrados],
          backgroundColor: [
            'rgba(75, 192, 192, 0.2)',
            'rgba(255, 99, 132, 0.2)',
          ],
          borderColor: [
            'rgba(75, 192, 192, 1)',
            'rgba(255, 99, 132, 1)',
          ],
          borderWidth: 1
        }]
      },
      options: {
        plugins: {
          title: {
            display: true,
            text: 'Desempenho nos Exercícios',
            fontSize: 16
          },
          tooltip: {
            mode: 'index',
            intersect: false
          }
        },
        scales: {
          x: {
            stacked: true,
            title: {
              display: true,
              text: 'Resultados'
            }
          },
          y: {
            stacked: true,
            ticks: {
              beginAtZero: true
            },
            title: {
              display: true,
              text: 'Quantidade'
            }
          }
        }
      }
    });
  });
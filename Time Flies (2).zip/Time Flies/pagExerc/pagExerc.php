<?php
require_once "../login/verificarLogin.php";
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TF-Exercícios</title>
    <link rel="stylesheet" href="styleExerc.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
</head>

<body>
</br>
    <div class="container">
        <h3>Meus Exercícios </h3>
        </br>
        <form action="processar_formulario.php" method="post">
            <div class="form-group">
                <label for="data"><strong>Data:</strong></label>
                <input type="date" id="data" name="data" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="total_questoes"><strong>Total de questões realizadas:</strong></label>
                <input type="number" id="total_questoes" name="total_questoes" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="acertos"><strong>Número de acertos:</strong></label>
                <input type="number" id="acertos" name="acertos" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="tipo_estudo"><strong>Tipo de Estudo:</strong></label>
                <select id="tipo_estudo" name="tipo_estudo" class="form-control" required>
                    <option value="ensino_regular">Ensino Regular</option>
                    <option value="concurso_publico">Concurso Público</option>
                </select>
            </div>
            <div class="form-group">
                <label for="materia"><strong>Matéria:</strong></label>
                <select id="materia" name="materia" class="form-control" required>
                    <!-- Matérias para Ensino Regular -->
                    <optgroup label="Ensino Regular">
                        <option value="portugues-regular">Português</option>
                        <option value="matematica-regular">Matemática</option>
                        <option value="historia-regular">História</option>
                        <option value="geografia-regular">Geografia</option>
                        <option value="ciencias-regular">Ciências</option>
                    </optgroup>
                    <!-- Matérias para Concurso Público -->
                    <optgroup label="Concurso Público">
                        <option value="portugues-concurso">Português</option>
                        <option value="matematica-concurso">Matemática</option>
                        <option value="direito-concurso">Direito</option>
                        <option value="informatica-concurso">Informática</option>
                        <option value="administracao-concurso">Administração</option>
                    </optgroup>
                </select>
            </div>
            <a href="../pagInicial/pagInicial.php" class="btn btn-info"><strong>Voltar</strong></a>
            <input type="submit" value="Enviar" class="btn btn-primary">
        </form></br>

        <form action="" method="post">
            <div class="btn-group">
                <input type="submit" name="gerar_relatorio" value="Gerar Relatório Detalhado" class="btn btn-info">
                <input type="submit" name="total_questoes_realizadas" value="Total de Questões Realizadas" class="btn btn-info">
                <input type="submit" name="total_questoes_erradas" value="Total de Questões Erradas" class="btn btn-info">
                <input type="submit" name="total_questoes_corretas" value="Total de Questões Corretas" class="btn btn-info">
            </div>
        </form>
    </div>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "time_fliesgerenciador";
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificar se algum botão foi pressionado
    if (isset($_POST['gerar_relatorio'])) {
        // Lógica para gerar relatório detalhado
        $sql = "SELECT * FROM questoes";
        $result = $conn->query($sql);

        echo "<div class='container'>";
        echo "<h2></h2>";
        echo "<table class='table'>";
        echo "<tr><th>Data</th><th>Total de Questões</th><th>Acertos</th><th>Erradas</th></tr>";

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['data'] . "</td>";
                echo "<td>" . $row['total_questoes'] . "</td>";
                echo "<td>" . $row['acertos'] . "</td>";
                echo "<td>" . $row['erradas'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>Nenhum registro encontrado.</td></tr>";
        }

        echo "</table>";
        echo "</div>";
    } elseif (isset($_POST['total_questoes_realizadas'])) {
        $sql = "SELECT SUM(total_questoes) AS total FROM questoes";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        echo "<div class='container'>";
        echo "<p><strong>Total de Questões Realizadas: " . $row['total'] . "</strong></p>";
        echo "</div>";
    } elseif (isset($_POST['total_questoes_erradas'])) {
        $sql = "SELECT SUM(erradas) AS total FROM questoes";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        echo "<div class='container'>";
        echo "<p><strong>Total de Questões Erradas: " . $row['total'] . "</strong></p>";
        echo "</div>";
    } elseif (isset($_POST['total_questoes_corretas'])) {
        $sql = "SELECT SUM(acertos) AS total FROM questoes";
        $result = $conn->query($sql);
        $row = $result->fetch_assoc();
        echo "<div class='container'>";
        echo "<p><strong>Total de Questões Corretas: " . $row['total'] . "</stronh></p>";
        echo "</div>";
    }

    $conn->close();
    ?>
<footer class="bg-dark text-light text-center py-3">
    <div class="container">
        <p>&copy; 2024 Time Flies. Todos os direitos reservados.</p>
    </div>
</footer>
</body>
</html>
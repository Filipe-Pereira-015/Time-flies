<?php
require_once "../login/verificarLogin.php";
?>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

$sql = "SELECT materia, SUM(total_questoes) AS total_questoes, SUM(acertos) AS total_acertos, SUM(erradas) AS total_erradas FROM questoes GROUP BY materia";
$stmt = $conn->prepare($sql);
$stmt->execute();
$result = $stmt->get_result();

$analise_materias = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $materia = $row['materia'];
        $analise_materias[$materia] = array(
            'total_questoes' => $row['total_questoes'],
            'total_acertos' => $row['total_acertos'],
            'total_erradas' => $row['total_erradas']
        );
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TF-Relatórios</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="icon" type="image/png" href="../img/icon.jpg" />
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawCharts);

        function drawCharts() {
            <?php foreach ($analise_materias as $materia => $dados): ?>
                // Gráfico de Barras
                var dataAcertos<?php echo str_replace("-", "_", $materia); ?> = google.visualization.arrayToDataTable([
                    ['Categoria', 'Quantidade'],
                    ['Acertos', <?php echo $dados['total_acertos']; ?>],
                    ['Erradas', <?php echo $dados['total_erradas']; ?>]
                ]);
                var optionsAcertos<?php echo str_replace("-", "_", $materia); ?> = {
                    title: 'Desempenho por Matéria (<?php echo ucfirst(str_replace("_", " ", $materia)); ?>)',
                    legend: { position: 'top' },
                    colors: ['#28a745', '#dc3545']
                };
                var chartAcertos<?php echo str_replace("-", "_", $materia); ?> = new google.visualization.ColumnChart(document.getElementById('grafico-acertos-<?php echo str_replace("-", "_", $materia); ?>'));
                chartAcertos<?php echo str_replace("-", "_", $materia); ?>.draw(dataAcertos<?php echo str_replace("-", "_", $materia); ?>, optionsAcertos<?php echo str_replace("-", "_", $materia); ?>);

                // Gráfico de Pizza
                var dataErradas<?php echo str_replace("-", "_", $materia); ?> = google.visualization.arrayToDataTable([
                    ['Categoria', 'Percentual'],
                    ['Acertos', <?php echo ($dados['total_acertos'] / $dados['total_questoes']) * 100; ?>],
                    ['Erradas', <?php echo ($dados['total_erradas'] / $dados['total_questoes']) * 100; ?>]
                ]);
                var optionsErradas<?php echo str_replace("-", "_", $materia); ?> = {
                    title: 'Percentual de Acertos e Erradas (<?php echo ucfirst(str_replace("_", " ", $materia)); ?>)',
                    pieSliceText: 'value',
                    colors: ['#28a745', '#dc3545']
                };
                var chartErradas<?php echo str_replace("-", "_", $materia); ?> = new google.visualization.PieChart(document.getElementById('grafico-erradas-<?php echo str_replace("-", "_", $materia); ?>'));
                chartErradas<?php echo str_replace("-", "_", $materia); ?>.draw(dataErradas<?php echo str_replace("-", "_", $materia); ?>, optionsErradas<?php echo str_replace("-", "_", $materia); ?>);
            <?php endforeach; ?>
        }
    </script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        h2 {
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .tab {
            overflow: hidden;
            border-bottom: 1px solid #ccc;
            margin-top: 20px;
        }
        .tab button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }
        .tab button:hover {
            background-color: #ddd;
        }
        .tab button.active {
            background-color: #ccc;
        }
        .tabcontent {
            display: none;
            padding: 20px;
        }
        .chart-container {
            width: 100%;
            display: flex;
            justify-content: space-around;
            margin-top: 20px;
        }
        .chart {
            width: 45%;
            height: 300px;
        }
        footer {
            background-color: #343a40;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Resumo Geral</h2>
    <table border='1'>
        <tr>
            <th>Total de Questões Respondidas</th>
            <th>Total de Acertos</th>
            <th>Total de Erradas</th>
        </tr>
        <tr>
            <?php
            $total_questoes = $total_acertos = $total_erradas = 0;
            foreach ($analise_materias as $materia => $dados) {
                $total_questoes += $dados['total_questoes'];
                $total_acertos += $dados['total_acertos'];
                $total_erradas += $dados['total_erradas'];
            }
            ?>
            <td><?php echo $total_questoes; ?></td>
            <td><?php echo $total_acertos; ?></td>
            <td><?php echo $total_erradas; ?></td>
        </tr>
    </table>

    <h2>Relatório Detalhado</h2>
    <a href="../pagInicial/pagInicial.php" class="btn btn-info"><strong>Voltar</strong></a>

    <table class="table table-striped">
        <thead>
        <tr>
            <th>Matéria</th>
            <th>Total de Questões</th>
            <th>Total de Acertos</th>
            <th>Total de Erradas</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($analise_materias as $materia => $dados): ?>
            <tr>
                <td><?php echo ucfirst(str_replace("_", " ", $materia)); ?></td>
                <td><?php echo $dados['total_questoes']; ?></td>
                <td><?php echo $dados['total_acertos']; ?></td>
                <td><?php echo $dados['total_erradas']; ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <h2>Gráficos de Desempenho</h2>
    <div class="tab">
        <?php foreach ($analise_materias as $materia => $dados): ?>
            <button class="tablinks" onclick="openTab(event, '<?php echo str_replace("-", "_", $materia); ?>')"><?php echo ucfirst(str_replace("_", " ", $materia)); ?></button>
        <?php endforeach; ?>
    </div>

    <?php foreach ($analise_materias as $materia => $dados): ?>
        <div id="<?php echo str_replace("-", "_", $materia); ?>" class="tabcontent">
            <div id="grafico-acertos-<?php echo str_replace("-", "_", $materia); ?>" class="chart"></div>
            <div id="grafico-erradas-<?php echo str_replace("-", "_", $materia); ?>" class="chart"></div>
        </div>
    <?php endforeach; ?>
</div>

<script>
    function openTab(evt, tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        evt.currentTarget.className += " active";
    }

    // Show the first tab by default
    document.getElementsByClassName("tablinks")[0].click();
</script>
<footer>
    <div class="container">
        <p>&copy; 2024 Time Flies. Todos os direitos reservados.</p>
    </div>
</footer>
</body>
</html>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "time_fliesgerenciador";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Erro na conexão com o banco de dados: " . $conn->connect_error);
}

// Captura os dados do formulário
$data = $_POST['data'];
$total_questoes = $_POST['total_questoes'];
$acertos = $_POST['acertos'];
$tipo_estudo = $_POST['tipo_estudo'];
$materia = $_POST['materia'];

// Calcula o número de questões erradas
$erradas = $total_questoes - $acertos;

// Prepara e executa a consulta SQL para inserir os dados
$sql = "INSERT INTO questoes (data, total_questoes, acertos, erradas, tipo_estudo, materia) VALUES ('$data', '$total_questoes', '$acertos', '$erradas', '$tipo_estudo', '$materia')";

if ($conn->query($sql) === TRUE) {
    echo "Dados inseridos com sucesso.";
} else {
    echo "Erro ao inserir dados: " . $conn->error;
}

$conn->close();
header("Location: pagExerc.php");
exit();
?>